sh 01-init-customer.sh
printf "\n\n"

sh 02-init-admin.sh
printf "\n\n"

sh 03-init-apisix.sh
printf "\n\n"

sh 06_init-reserved-profile.sh
printf "\n\n"
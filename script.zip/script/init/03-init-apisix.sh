sh 04-init-apisix-upstreams.sh
printf "\n\n"

sh 05-init-apisix-routes.sh
printf "\n\n"